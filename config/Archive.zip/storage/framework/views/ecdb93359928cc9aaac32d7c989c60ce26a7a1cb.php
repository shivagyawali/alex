<div id="emailModal" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Send Us Email</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <?php echo e(Form::open(['method'=>'post','id'=>'emailForm'])); ?>


            

            <div class="form-group">
                <?php echo e(Form::label('name','Your Name')); ?>


                <?php echo e(Form::text('name',null,['class'=>'form-control'])); ?>

            </div>


            
            <div class="form-group">
                <?php echo e(Form::label('email','Your email')); ?>


                <?php echo e(Form::text('email',null,['class'=>'form-control'])); ?>

            </div>


            
            <div class="form-group">
                <?php echo e(Form::label('mobile','Your mobile')); ?>


                <?php echo e(Form::text('mobile',null,['class'=>'form-control'])); ?>

            </div>



            


            <div class="form-group">
                <?php echo e(Form::label('message','Your message')); ?>


                <?php echo e(Form::textarea('message',null,['class'=>'form-control'])); ?>

            </div>


            <button class="btn btn-primary" type="submit" id="email" >Send</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

            <?php echo e(Form::close()); ?>

        </div>
        
      </div>
    </div>
  </div>
<?php /**PATH /Users/techtemple/Desktop/stockAPI/resources/views/frontend/email-modal.blade.php ENDPATH**/ ?>