<div id="personal_consultancy-" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog-full-screen" role="document">
      <div class="modal-content-full-screen">
        <div class="modal-header-full-screen">
          <h5 class="modal-title-full-screen"><?php echo e($setting->personal_consultancy); ?></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;Close</span>
          </button>
        </div>
        <div class="modal-body-full-screen" id="pdf-viewer-body">

            <?php $__currentLoopData = $personal_consultancy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            



            <iframe frameborder="0" scrolling="no" style="border:0px" src="<?php echo e(asset('uploads/'.$value->pdf)); ?>" width="100%"
                height="100%">
            </iframe>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        






      </div>
    </div>
  </div>
<?php /**PATH /Users/techtemple/Desktop/stockAPI/resources/views/frontend/personal-consultancy.blade.php ENDPATH**/ ?>