
<div id="liveModal-error" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Wait</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

            <div class="row black">


            <div class="form-group">

                <center>

                <img id="countdown" style="color:green" >
                <p id="loader" class="loader"></p>
                <p id="message-after-countdown" style="color: red"></p>
                </center>

            </div>

            </div>
        </div>
        
      </div>
    </div>
  </div>


<?php /**PATH /Users/techtemple/Desktop/stockAPI/resources/views/frontend/error-message-live-chat.blade.php ENDPATH**/ ?>