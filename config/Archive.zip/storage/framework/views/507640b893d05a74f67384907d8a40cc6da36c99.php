<div id="who_are_we" class="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog-full-screen" role="document">
      <div class="modal-content-full-screen">
        <div class="modal-header">
          <h5 class="modal-title"><?php echo e($setting->who_are_we); ?></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;Close</span>
          </button>
        </div>
        <div class="modal-body-full-screen" id="pdf-viewer-body">

            <?php $__currentLoopData = $who_are_we; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            



            <iframe frameborder="0" scrolling="no" style="border:0px" src="<?php echo e(asset('uploads/'.$value->pdf)); ?>" width="100%"
                height="100%">
            </iframe>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        






      </div>
    </div>
  </div>
<?php /**PATH /Users/techtemple/Desktop/stockAPI/resources/views/frontend/who-are-we.blade.php ENDPATH**/ ?>