<?php

use App\Models\Setting;

function updateSetting($parameter,$value){

    $setting = Setting::first();
    $setting->$parameter =$value;

    $setting->save();

    return true;

}



function bitcoin(){

    // $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=BTC&to_symbol=USD&apikey=SEYBL927E4GEISL6');


    // $json = file_get_contents('https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=BTC&interval=5min&apikey=SEYBL927E4GEISL6');

    $json = file_get_contents('https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol=BTC&market=USD&apikey=SEYBL927E4GEISL6');


    // $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=BTC&to_symbol=USD&apikey=SEYBL927E4GEISL6');



    $data = json_decode($json,true);

    // dd($data["Time Series Crypto (5min)"]);

    //  dd($data);

    $count =0;


    $bitcoin = [];



    try{
        $data["Time Series (Digital Currency Daily)"];

    }catch(Exception $e){
            dd('API error occured , please wait and try again');
    }



    foreach($data["Time Series (Digital Currency Daily)"] as $value){

        if($count==2){
            break;
        }
            // echo $value['1. open'];

            $bitcoin[]=$value['4a. close (USD)'];
            echo "<BR>";

            $count++;



    }


    $change_in_bitcoin = $bitcoin[0]-$bitcoin[1];



    if($change_in_bitcoin>0){
        $change_in_bitcoin = "<span style='color:green'> + $change_in_bitcoin</span>";
    }else{
        $change_in_bitcoin = "<span style='color:red'> -$change_in_bitcoin </span>";

    }


    return [$bitcoin,$change_in_bitcoin];
}



// dow


function dow(){
    $json = file_get_contents('https://www.alphavantage.co/query?function=CRYPTO_INTRADAY&symbol=Dow&market=USD&interval=5min&apikey=SEYBL927E4GEISL6');

    $data = json_decode($json,true);

    dd($data);

    // dd($data["Time Series Crypto (5min)"]);

    $count =0;


    $bitcoin = [];


    foreach($data["Time Series Crypto (5min)"] as $value){

        if($count==2){
            break;
        }
            // echo $value['1. open'];

            $bitcoin[]=$value['4. close'];
            echo "<BR>";

            $count++;



    }


    $change_in_bitcoin = $bitcoin[0]-$bitcoin[1];



    if($change_in_bitcoin>0){
        $change_in_bitcoin = "<span style='color:green'> + $change_in_bitcoin</span>";
    }else{
        $change_in_bitcoin = "<span style='color:red'> -$change_in_bitcoin </span>";

    }


    return [$bitcoin,$change_in_bitcoin];
}


function NASDAQ(){

    $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=BTC&to_symbol=USD&apikey=SEYBL927E4GEISL6');

    $data = json_decode($json,true);

    // dd($data["Time Series Crypto (5min)"]);

    $count =0;


    $bitcoin = [];


    foreach($data["Time Series FX (Daily)"] as $value){

        if($count==2){
            break;
        }
            // echo $value['1. open'];

            $bitcoin[]=$value['4. close'];
            echo "<BR>";

            $count++;



    }


    $change_in_bitcoin = $bitcoin[0]-$bitcoin[1];



    if($change_in_bitcoin>0){
        $change_in_bitcoin = "<span style='color:green'> + $change_in_bitcoin</span>";
    }else{
        $change_in_bitcoin = "<span style='color:red'> -$change_in_bitcoin </span>";

    }


    return [$bitcoin,$change_in_bitcoin];
}




function usdToEuro(){
    // $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=EUR&to_symbol=USD&interval=5min&apikey=SEYBL927E4GEISL6');


    $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=EUR&to_symbol=USD&apikey=SEYBL927E4GEISL6');
    // $json = file_get_contents('https://www.alphavantage.co/query?function=FX_DAILY&from_symbol=EURO&to_symbol=USD&apikey=SEYBL927E4GEISL6');

$data = json_decode($json,true);



$count=0;

$eur=[];


try{
    $data["Time Series FX (Daily)"];

}catch(Exception $e){
        dd('API error occured , please wait and try again');
}

foreach($data["Time Series FX (Daily)"] as $value){

    if($count==2){
        break;
    }
        // echo $value['1. open'];

        $eur[]=$value['4. close'];
        echo "<BR>";

        $count++;



}


$change_in_bitcoin = $eur[0]-$eur[1];



if($change_in_bitcoin>0){
    $change_in_bitcoin = "<span style='color:green'> + $change_in_bitcoin</span>";
}else{
    $change_in_bitcoin = "<span style='color:red'> -$change_in_bitcoin </span>";

}


return [$eur,$change_in_bitcoin];
}
