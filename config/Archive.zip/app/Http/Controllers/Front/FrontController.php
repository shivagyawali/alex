<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Mail\ContactEmail;
use App\Models\ContactUs;
use App\Models\Course;
use App\Models\Home;
use App\Models\PersonalConsultancy;
use App\Models\Setting;
use App\Models\StockAnalysis;
use App\Models\TermsAndCondition;
use App\Models\WhoAreWe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use httpclient;

class FrontController extends Controller
{

    public $setting;

    public function __construct()
    {
        $this->setting = Setting::first();
    }
    public function index(){




    $bitcoin = bitcoin();


    $eur_to_usd = usdToEuro();

    //  dd($eur_to_usd);


    // for gold


    $home_pdf = Home::orderBy('created_at','DESC')->where('status',1)->get();
    $who_are_we =  WhoAreWe::orderBy('created_at','DESC')->where('status',1)->get();
    $personal_consultancy = PersonalConsultancy::orderBy('created_at','DESC')->where('status',1)->get();
    $courses = Course::orderBy('created_at','DESC')->where('status',1)->get();
    $stock_analysis = StockAnalysis::orderBy('created_at','DESC')->where('status',1)->get();
    $contact_us = ContactUs::orderBy('created_at','DESC')->where('status',1)->get();
    $terms_and_conditions = TermsAndCondition::orderBy('created_at','DESC')->where('status',1)->get();



        $setting = Setting::first();
        return view('frontend.index',
            compact('setting',
            'bitcoin',
            'eur_to_usd',
            'home_pdf',
            'who_are_we',
            'personal_consultancy',
            'courses',
            'stock_analysis',
            'contact_us',
            'terms_and_conditions'
            )
        );
    }


    public function sendEmail(Request $request){
        $rules = [
            'name'=>'required',
            'email'=>'required|email',
            'mobile'=>'required',
            'message'=>'required'
        ];

        $request->validate($rules);


        Mail::to('swagatgyawali11345@gmail.com')->send(new ContactEmail($request));

        return response()->json(['200','email sent']);
        // return redirect()->back()->with('message','Your Email sent successfully!');
    }


    public function liveChat(Request $request){
        $rules = [
            'name'=>'required',
            'email'=>'required|email',
            'mobile'=>'required',
            'message'=>'required'
        ];

        $request->validate($rules);


        Mail::to('swagatgyawali11345@gmail.com')->send(new ContactEmail($request));


        return response()->json(['200','live chat sent']);
    }




}
